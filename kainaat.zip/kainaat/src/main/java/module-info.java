module com.example.kainaat {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.kainaat to javafx.fxml;
    exports com.example.kainaat;
}